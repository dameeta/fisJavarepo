package com.pack.array;
class MyDate{
	private int day;
	private int month;
	private int year;
	
	public MyDate(int d,int m,int y)
	{
		this.day=d;
		this.month=m;
		this.year=y;
	}
	
	public String toString()
	{
		return  "["+this.day +"/"+ this.month +"/"+this.year+"]";
	}
}

public class ObjectArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//homogeneous collection
MyDate [] dates =new MyDate[3];

dates[0]=new MyDate(12, 3,2021);
dates[1]=new MyDate(1, 3,2021);;
dates[2]=new MyDate(2, 3,2021);;

	for(int i=0;i<dates.length;i++)
	{
		System.out.println(dates[i]);
	}
	}

}
