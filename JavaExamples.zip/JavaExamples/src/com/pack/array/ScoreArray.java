package com.pack.array;

public class ScoreArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String st_name[]=new String[5];


	}

}
