package com.pack.array;

public class ArrayDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            int id[]=new int[]{1,2,3,4,5};
           /* id[0]= 101;
            id[1]= 102;
            id[2]= 103;
            id[3]= 104;
            id[4]= 105;*/

		for(int i=0;i<=4;i++)
		{
			System.out.print(id[i]+"\t");
		}
	}

}
