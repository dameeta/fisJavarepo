package com.pack.contrlstatements;

public class doWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int i=1,x=2;

/* do{
	 
	 System.out.println(x*i);
	 i++;
     }
 while( i<11);
*/	
		 /*for(i=1;i<=10;i++)
		 {
			 System.out.println(x+"*"+i+"=" + x*i);
		 }*/
		 boolean ans=true;
		 while(true){
			 System.out.println("hi");
			 break;
			 
		 }
		 do{
			 
			 System.out.println(x*i);
			 i++;
			 continue;
		     }
		 while( i<11);
		 
		 ;

		 
	}
	
	}


