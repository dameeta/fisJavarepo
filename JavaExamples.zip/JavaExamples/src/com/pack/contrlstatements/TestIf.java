package com.pack.contrlstatements;

public class TestIf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int age=23;
		if(age <= 21)
		{
			System.out.println("Not eligible for voting");
					
		}
		else{
			
			System.out.println("eligible ");
		}
		
		
	}

}
