package com.pack.oops;

class Trustee{
	
}
class Principal extends Trustee{
	
	
}
class Supervisor extends Principal{
	
	
}
class HeadofDept extends Supervisor{
	
}
class MathsDept  extends HeadofDept{
	
}
class BiologyDept extends HeadofDept{
	
}
class ChemistDept extends HeadofDept{
	
}
public class HierarchicalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
