package com.pack.ex;

public class Operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x=1;
int y=1;
//it assigns and then increments=>post increments
//it increments and then assigns=> pre increments
System.out.println(++x);
System.out.println(++x);
		
--x;
System.out.println(x);
y++;
System.out.println(y);
	}

}
