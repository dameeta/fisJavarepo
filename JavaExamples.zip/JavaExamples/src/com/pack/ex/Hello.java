package com.pack.ex;
import com.pack.oops.CurrentAccount;
import java.util.Scanner;


public class Hello {
//default
	int x=10;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
            System.out.println("hello");
           /* int v1=101;
            float f1=1.34f;
            double d1=567.45;
            char ans='Y';
            short s1=34;
            long l1= 83794830984l;
            boolean val=true;
            byte b1=010;
            
            Scanner sc=new Scanner(System.in);
           v1=sc.nextInt();
	*/
    CurrentAccount c1=new CurrentAccount();
    
	}

}
