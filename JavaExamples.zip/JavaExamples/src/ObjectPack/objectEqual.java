package ObjectPack;

class data {}


public class objectEqual {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
data d1=new data();
data d2=new data();
//d1=d2;

System.out.println(d1+" \t"+d2);

System.out.println(d1==d2);
	}

}
